const express = require('express');
const router = express.Router();
const { Pool } = require('pg');
const authenticateUser = require('../middleware/auth');
const requireAdmin = require('../middleware/adminAuth');

// Database connection
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// MARK: - User Subscription Endpoints

/**
 * GET /api/subscription/status
 * Check current subscription status for authenticated user
 */
router.get('/status', authenticateUser, async (req, res) => {
    try {
        const userId = req.user.id;
        
        const result = await pool.query(
            'SELECT * FROM users WHERE user_id = $1',
            [userId]
        );
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        const user = result.rows[0];
        const now = new Date();
        const endDate = user.subscription_end_date ? new Date(user.subscription_end_date) : null;
        
        let daysRemaining = 0;
        let accessGranted = false;
        
        if (endDate) {
            const diffTime = endDate - now;
            daysRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
            accessGranted = now <= endDate && user.is_active && !user.is_banned;
        }
        
        // Auto-update status if expired
        if (endDate && now > endDate && user.subscription_status !== 'expired') {
            await pool.query(
                'UPDATE users SET subscription_status = $1 WHERE user_id = $2',
                ['expired', userId]
            );
            user.subscription_status = 'expired';
        }
        
        res.json({
            user_id: userId,
            subscription_status: user.subscription_status,
            subscription_end_date: user.subscription_end_date,
            days_remaining: daysRemaining,
            access_granted: accessGranted,
            trial_active: user.subscription_status === 'trial',
            promo_code_used: user.promo_code_used
        });
        
    } catch (error) {
        console.error('Error checking subscription status:', error);
        res.status(500).json({ error: 'Failed to check subscription status' });
    }
});

/**
 * POST /api/subscription/activate-promo
 * Activate a promo code for the authenticated user
 */
router.post('/activate-promo', authenticateUser, async (req, res) => {
    const client = await pool.connect();
    
    try {
        const { promo_code } = req.body;
        const userId = req.user.id;
        
        if (!promo_code) {
            return res.status(400).json({ 
                success: false,
                error: 'Promo code is required' 
            });
        }
        
        await client.query('BEGIN');
        
        // 1. Validate promo code
        const promoResult = await client.query(
            'SELECT * FROM promo_codes WHERE code = $1 AND active = true',
            [promo_code.toUpperCase()]
        );
        
        if (promoResult.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ 
                success: false,
                message: 'Invalid or inactive promo code' 
            });
        }
        
        const promo = promoResult.rows[0];
        
        // 2. Check expiration
        if (promo.expires_at && new Date(promo.expires_at) < new Date()) {
            await client.query('ROLLBACK');
            return res.status(400).json({ 
                success: false,
                message: 'This promo code has expired' 
            });
        }
        
        // 3. Check uses remaining
        if (promo.uses_remaining !== null && promo.uses_remaining <= 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ 
                success: false,
                message: 'This promo code has been fully redeemed' 
            });
        }
        
        // 4. Check if user already used this code
        const usageResult = await client.query(
            'SELECT * FROM promo_code_usage WHERE promo_code_id = $1 AND user_id = $2',
            [promo.id, userId]
        );
        
        if (usageResult.rows.length > 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ 
                success: false,
                message: 'You have already used this promo code' 
            });
        }
        
        // 5. Calculate new subscription dates
        const startDate = new Date();
        const endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + promo.duration_days);
        
        // 6. Update user subscription
        await client.query(`
            UPDATE users 
            SET subscription_status = 'promo_active',
                subscription_start_date = $1,
                subscription_end_date = $2,
                promo_code_used = $3,
                promo_activated_at = $1,
                updated_at = NOW()
            WHERE user_id = $4
        `, [startDate, endDate, promo_code.toUpperCase(), userId]);
        
        // 7. Record usage
        await client.query(`
            INSERT INTO promo_code_usage (promo_code_id, user_id, ip_address)
            VALUES ($1, $2, $3)
        `, [promo.id, userId, req.ip]);
        
        // 8. Update promo code stats
        if (promo.uses_remaining !== null) {
            await client.query(`
                UPDATE promo_codes 
                SET uses_remaining = uses_remaining - 1,
                    used_count = used_count + 1
                WHERE id = $1
            `, [promo.id]);
        } else {
            await client.query(`
                UPDATE promo_codes 
                SET used_count = used_count + 1
                WHERE id = $1
            `, [promo.id]);
        }
        
        // 9. Log in subscription history
        await client.query(`
            INSERT INTO subscription_history 
            (user_id, event_type, new_status, new_end_date, metadata)
            VALUES ($1, 'promo_activated', 'promo_active', $2, $3)
        `, [userId, endDate, JSON.stringify({ promo_code: promo_code.toUpperCase(), duration_days: promo.duration_days })]);
        
        await client.query('COMMIT');
        
        res.json({
            success: true,
            message: `Promo code activated! You now have ${promo.duration_days} days of access.`,
            subscription_end_date: endDate.toISOString(),
            days_granted: promo.duration_days
        });
        
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error activating promo code:', error);
        res.status(500).json({ 
            success: false,
            message: 'Failed to activate promo code' 
        });
    } finally {
        client.release();
    }
});

/**
 * POST /api/subscription/check-promo
 * Validate a promo code without activating it
 */
router.post('/check-promo', authenticateUser, async (req, res) => {
    try {
        const { promo_code } = req.body;
        const userId = req.user.id;
        
        const promoResult = await pool.query(
            'SELECT * FROM promo_codes WHERE code = $1 AND active = true',
            [promo_code.toUpperCase()]
        );
        
        if (promoResult.rows.length === 0) {
            return res.json({ 
                valid: false,
                message: 'Invalid promo code' 
            });
        }
        
        const promo = promoResult.rows[0];
        
        // Check expiration
        if (promo.expires_at && new Date(promo.expires_at) < new Date()) {
            return res.json({ 
                valid: false,
                message: 'This promo code has expired' 
            });
        }
        
        // Check uses
        if (promo.uses_remaining !== null && promo.uses_remaining <= 0) {
            return res.json({ 
                valid: false,
                message: 'This promo code has no uses remaining' 
            });
        }
        
        // Check if user already used it
        const usageResult = await pool.query(
            'SELECT * FROM promo_code_usage WHERE promo_code_id = $1 AND user_id = $2',
            [promo.id, userId]
        );
        
        if (usageResult.rows.length > 0) {
            return res.json({ 
                valid: false,
                message: 'You have already used this promo code' 
            });
        }
        
        res.json({
            valid: true,
            message: `Valid! This code grants ${promo.duration_days} days of access.`,
            duration_days: promo.duration_days,
            uses_remaining: promo.uses_remaining
        });
        
    } catch (error) {
        console.error('Error checking promo code:', error);
        res.status(500).json({ error: 'Failed to check promo code' });
    }
});

module.exports = router;

