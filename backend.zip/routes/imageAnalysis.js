/**
 * Image Analysis Routes
 * Handles image validation and homework analysis
 */

const express = require('express');
const multer = require('multer');
const openaiService = require('../services/openaiService');
const azureService = require('../services/azureService');
const router = express.Router();

// Configure multer for image uploads
const storage = multer.memoryStorage();
const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024 // 10MB limit
    }
});

/**
 * POST /api/validate-image
 * Validates image quality for homework analysis
 */
router.post('/validate-image', upload.single('image'), async (req, res) => {
    try {
        console.log('🔍 Image validation request received');
        
        if (!req.file) {
            return res.status(400).json({ 
                error: 'No image file provided',
                isGoodQuality: false,
                confidence: 0.0,
                issues: ['No image file uploaded'],
                recommendations: []
            });
        }
        
        const imageBuffer = req.file.buffer;
        const imageSize = imageBuffer.length;
        
        console.log(`📊 Image size: ${(imageSize / 1024).toFixed(2)} KB`);
        
        // Basic file size validation first
        if (imageSize < 10 * 1024) {
            return res.json({
                isGoodQuality: false,
                confidence: 0.0,
                issues: ['Image is too small (minimum 10KB required)'],
                recommendations: ['Take a higher resolution photo or get closer to the homework']
            });
        }
        
        if (imageSize > 10 * 1024 * 1024) {
            return res.json({
                isGoodQuality: false,
                confidence: 0.0,
                issues: ['Image is too large (maximum 10MB allowed)'],
                recommendations: ['Compress the image or take a new photo']
            });
        }
        
        // Check if it's a valid image format
        const isValidFormat = checkImageFormat(imageBuffer);
        if (!isValidFormat) {
            return res.json({
                isGoodQuality: false,
                confidence: 0.0,
                issues: ['Invalid image format (only JPEG, PNG, HEIC supported)'],
                recommendations: ['Save the image in JPEG or PNG format']
            });
        }
        
        // Use OpenAI to analyze image quality
        console.log('🤖 Using OpenAI to analyze image quality...');
        const apiKey = process.env.OPENAI_API_KEY;
        
        if (!apiKey) {
            console.error('❌ OpenAI API key not found in environment variables');
            // Fallback to basic validation if OpenAI fails
            return res.json({
                isGoodQuality: isValidFormat && imageSize >= 10 * 1024 && imageSize <= 10 * 1024 * 1024,
                confidence: 0.5,
                issues: isValidFormat ? [] : ['Could not verify image format'],
                recommendations: [
                    'Ensure the image is clear and well-lit',
                    'Make sure the homework text is readable',
                    'Avoid blurry or dark images'
                ]
            });
        }
        
        const qualityAnalysis = await openaiService.validateImageQuality({
            imageData: imageBuffer,
            apiKey: apiKey
        });
        
        console.log(`✅ OpenAI image validation completed - Quality: ${qualityAnalysis.isGoodQuality}, Confidence: ${qualityAnalysis.confidence}`);
        
        // Return the validation result in the expected format
        res.json({
            isGoodQuality: qualityAnalysis.isGoodQuality,
            confidence: qualityAnalysis.confidence,
            issues: qualityAnalysis.issues || [],
            recommendations: qualityAnalysis.recommendations || []
        });
        
    } catch (error) {
        console.error('Image validation error:', error);
        
        // Fallback to basic validation if OpenAI fails
        if (req.file) {
            const imageSize = req.file.buffer.length;
            const isValidFormat = checkImageFormat(req.file.buffer);
            
            res.json({
                isGoodQuality: isValidFormat && imageSize >= 10 * 1024 && imageSize <= 10 * 1024 * 1024,
                confidence: 0.5,
                issues: isValidFormat ? [] : ['Could not verify image format'],
                recommendations: [
                    'Ensure the image is clear and well-lit',
                    'Make sure the homework text is readable',
                    'Avoid blurry or dark images'
                ]
            });
        } else {
            res.status(500).json({ 
                error: 'Image validation failed',
                isGoodQuality: false,
                confidence: 0.0,
                issues: ['Server error during validation'],
                recommendations: []
            });
        }
    }
});

/**
 * POST /api/analyze-homework
 * Analyzes homework image and provides solutions
 */
router.post('/analyze-homework', upload.single('image'), async (req, res) => {
    try {
        console.log('🔍 Homework analysis request received');
        
        const { problemText, userGradeLevel } = req.body;
        const imageFile = req.file;
        
        if (!imageFile && !problemText) {
            return res.status(400).json({ 
                error: 'Either image file or problem text is required' 
            });
        }
        
        console.log(`📊 Analysis request - Image: ${!!imageFile}, Text: ${!!problemText}, Grade: ${userGradeLevel}`);
        
        // Use OpenAI to analyze the homework
        console.log('🤖 Using OpenAI to analyze homework...');
        const apiKey = process.env.OPENAI_API_KEY;
        
        if (!apiKey) {
            console.error('❌ OpenAI API key not found in environment variables');
            return res.status(500).json({ 
                error: 'AI service configuration error',
                message: 'OpenAI API key is not configured'
            });
        }
        
        const analysisResult = await openaiService.analyzeHomework({
            imageData: imageFile ? imageFile.buffer : null,
            problemText: problemText,
            userGradeLevel: userGradeLevel || 'elementary',
            apiKey: apiKey
        });
        
        console.log(`✅ OpenAI homework analysis completed - Subject: ${analysisResult.subject}, Difficulty: ${analysisResult.difficulty}, Steps: ${analysisResult.steps.length}`);
        
        // Return the analysis in the expected format
        res.json(analysisResult);
        
    } catch (error) {
        console.error('Homework analysis error:', error);
        
        // If OpenAI fails, return a helpful error message
        if (error.message.includes('Invalid OpenAI API key')) {
            res.status(500).json({ 
                error: 'AI service configuration error',
                message: 'OpenAI API key is not properly configured'
            });
        } else if (error.message.includes('rate limit')) {
            res.status(429).json({ 
                error: 'Service temporarily unavailable',
                message: 'AI analysis is temporarily unavailable due to high usage. Please try again in a few minutes.'
            });
        } else {
            res.status(500).json({ 
                error: 'Homework analysis failed',
                message: error.message 
            });
        }
    }
});

/**
 * Helper function to check image format
 */
function checkImageFormat(buffer) {
    // Check for common image file signatures
    const signatures = [
        { offset: 0, bytes: [0xFF, 0xD8, 0xFF] }, // JPEG
        { offset: 0, bytes: [0x89, 0x50, 0x4E, 0x47] }, // PNG
        { offset: 0, bytes: [0x47, 0x49, 0x46] }, // GIF
        { offset: 4, bytes: [0x66, 0x74, 0x79, 0x70] } // HEIC/HEIF (simplified check)
    ];
    
    for (const sig of signatures) {
        if (buffer.length > sig.offset + sig.bytes.length) {
            const matches = sig.bytes.every((byte, index) => 
                buffer[sig.offset + index] === byte
            );
            if (matches) return true;
        }
    }
    
    return false;
}

module.exports = router;
