// Admin Dashboard JavaScript
// Homework Helper Admin Panel

const API_BASE_URL = window.location.origin + '/api';
let currentUser = null;
let currentPage = 1;
let adminToken = localStorage.getItem('adminToken');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    if (adminToken) {
        checkAuth();
    } else {
        showLoginScreen();
    }
    
    setupEventListeners();
});

function setupEventListeners() {
    // Login form
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    
    // Create promo form
    document.getElementById('createPromoForm').addEventListener('submit', handleCreatePromo);
    
    // Create user form
    document.getElementById('createUserForm').addEventListener('submit', handleCreateUser);
    
    // Change password form
    document.getElementById('changePasswordForm').addEventListener('submit', handleChangePassword);
    
    // Edit membership form
    document.getElementById('editMembershipForm').addEventListener('submit', handleEditMembership);
    
    // Search
    document.getElementById('userSearch').addEventListener('keyup', (e) => {
        if (e.key === 'Enter') loadUsers();
    });
    
    document.getElementById('statusFilter').addEventListener('change', loadUsers);
}

// MARK: - Authentication

async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/admin-login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            adminToken = data.token;
            localStorage.setItem('adminToken', adminToken);
            currentUser = data.admin;
            showDashboard();
            loadDashboardData();
        } else {
            showError('loginError', data.error || 'Login failed');
        }
    } catch (error) {
        console.error('Login error:', error);
        showError('loginError', 'Network error. Please try again.');
    }
}

async function checkAuth() {
    try {
        const response = await apiRequest('/admin/stats', 'GET');
        if (response) {
            showDashboard();
            loadDashboardData();
        } else {
            logout();
        }
    } catch (error) {
        logout();
    }
}

function logout() {
    adminToken = null;
    localStorage.removeItem('adminToken');
    showLoginScreen();
}

function showLoginScreen() {
    document.getElementById('loginScreen').style.display = 'block';
    document.getElementById('dashboard').style.display = 'none';
}

function showDashboard() {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('dashboard').style.display = 'block';
}

// MARK: - API Helper

async function apiRequest(endpoint, method = 'GET', body = null) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${adminToken}`
        }
    };
    
    if (body) {
        options.body = JSON.stringify(body);
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
        
        if (response.status === 401) {
            logout();
            return null;
        }
        
        return await response.json();
    } catch (error) {
        console.error('API request error:', error);
        throw error;
    }
}

// MARK: - Navigation

function showTab(tabName) {
    // Update nav tabs
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Update sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    
    const sectionMap = {
        'dashboard': 'dashboardSection',
        'users': 'usersSection',
        'promo-codes': 'promoCodesSection'
    };
    
    document.getElementById(sectionMap[tabName]).classList.add('active');
    
    // Load data for the tab
    if (tabName === 'dashboard') {
        loadDashboardData();
    } else if (tabName === 'users') {
        loadUsers();
    } else if (tabName === 'promo-codes') {
        loadPromoCodes();
    }
}

// MARK: - Dashboard Stats

async function loadDashboardData() {
    try {
        const stats = await apiRequest('/admin/stats', 'GET');
        
        if (stats) {
            document.getElementById('totalUsers').textContent = stats.total_users || 0;
            document.getElementById('activeSubs').textContent = stats.active_subscriptions || 0;
            document.getElementById('trialUsers').textContent = stats.trial_users || 0;
            document.getElementById('expiredUsers').textContent = stats.expired_subscriptions || 0;
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// MARK: - Users Management

async function loadUsers(page = 1) {
    const search = document.getElementById('userSearch').value;
    const status = document.getElementById('statusFilter').value;
    
    const queryParams = new URLSearchParams({
        page,
        limit: 20,
        search,
        status
    });
    
    try {
        const data = await apiRequest(`/admin/users?${queryParams}`, 'GET');
        
        if (data) {
            displayUsers(data.users);
            displayPagination(data.pagination);
        }
    } catch (error) {
        console.error('Error loading users:', error);
        document.getElementById('usersTable').innerHTML = '<p class="loading">Failed to load users</p>';
    }
}

function displayUsers(users) {
    if (!users || users.length === 0) {
        document.getElementById('usersTable').innerHTML = '<p class="loading">No users found</p>';
        return;
    }
    
    const html = `
        <table>
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Status</th>
                    <th>Days Left</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${users.map(user => `
                    <tr>
                        <td>${user.email}</td>
                        <td>${user.username || '-'}</td>
                        <td>${getStatusBadge(user.subscription_status)}</td>
                        <td>${Math.floor(user.days_remaining)} days</td>
                        <td>${formatDate(user.created_at)}</td>
                        <td>
                            <button class="btn btn-primary btn-sm" onclick="viewUserDetails('${user.user_id}')">View</button>
                            <button class="btn btn-${user.is_active ? 'danger' : 'success'} btn-sm" 
                                    onclick="toggleUserAccess('${user.user_id}', ${!user.is_active})">
                                ${user.is_active ? 'Deactivate' : 'Activate'}
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    document.getElementById('usersTable').innerHTML = html;
}

function getStatusBadge(status) {
    const badges = {
        'trial': '<span class="badge badge-info">Trial</span>',
        'active': '<span class="badge badge-success">Active</span>',
        'promo_active': '<span class="badge badge-success">Promo</span>',
        'expired': '<span class="badge badge-danger">Expired</span>',
        'cancelled': '<span class="badge badge-warning">Cancelled</span>'
    };
    return badges[status] || `<span class="badge">${status}</span>`;
}

function displayPagination(pagination) {
    if (!pagination) return;
    
    let html = '';
    
    for (let i = 1; i <= pagination.totalPages; i++) {
        html += `<button class="${i === pagination.page ? 'active' : ''}" 
                         onclick="loadUsers(${i})">
                    ${i}
                 </button>`;
    }
    
    document.getElementById('usersPagination').innerHTML = html;
}

async function viewUserDetails(userId) {
    try {
        const data = await apiRequest(`/admin/users/${userId}`, 'GET');
        
        if (data) {
            const user = data.user;
            const history = data.subscription_history;
            
            const html = `
                <div class="form-group">
                    <label>User ID</label>
                    <input type="text" value="${user.user_id}" readonly>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" value="${user.email}" readonly>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <p>${getStatusBadge(user.subscription_status)}</p>
                </div>
                <div class="form-group">
                    <label>Subscription End</label>
                    <input type="text" value="${formatDate(user.subscription_end_date)}" readonly>
                </div>
                <div class="form-group">
                    <label>Promo Code Used</label>
                    <input type="text" value="${user.promo_code_used || 'None'}" readonly>
                </div>
                <div class="form-group">
                    <label>Quick Actions</label>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <button class="btn btn-success" onclick="extendSubscription('${user.user_id}', 30)">
                            +30 Days
                        </button>
                        <button class="btn btn-success" onclick="extendSubscription('${user.user_id}', 90)">
                            +90 Days
                        </button>
                        <button class="btn btn-danger" onclick="banUser('${user.user_id}', ${!user.is_banned})">
                            ${user.is_banned ? 'Unban' : 'Ban'} User
                        </button>
                    </div>
                </div>
                <div class="form-group">
                    <label>Management Actions</label>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <button class="btn btn-primary" onclick="showChangePasswordModal('${user.user_id}')">
                            Change Password
                        </button>
                        <button class="btn btn-primary" onclick="showEditMembershipModal('${user.user_id}', ${JSON.stringify(user).replace(/"/g, '&quot;')})">
                            Edit Membership
                        </button>
                        <button class="btn btn-danger" onclick="deleteUser('${user.user_id}', '${user.email}')">
                            Delete User
                        </button>
                    </div>
                </div>
                <h3 style="margin-top: 20px;">Subscription History</h3>
                <div style="max-height: 200px; overflow-y: auto; margin-top: 10px;">
                    ${history.map(h => `
                        <div style="padding: 10px; border-bottom: 1px solid #eee;">
                            <strong>${h.event_type}</strong> - ${formatDate(h.created_at)}
                        </div>
                    `).join('')}
                </div>
            `;
            
            document.getElementById('userDetailsContent').innerHTML = html;
            showModal('userDetailsModal');
        }
    } catch (error) {
        console.error('Error loading user details:', error);
        alert('Failed to load user details');
    }
}

async function toggleUserAccess(userId, isActive) {
    if (!confirm(`Are you sure you want to ${isActive ? 'activate' : 'deactivate'} this user?`)) {
        return;
    }
    
    try {
        const result = await apiRequest(`/admin/users/${userId}/toggle-access`, 'POST', { is_active: isActive });
        
        if (result && result.success) {
            alert(result.message);
            loadUsers();
        }
    } catch (error) {
        console.error('Error toggling access:', error);
        alert('Failed to toggle user access');
    }
}

async function extendSubscription(userId, days) {
    if (!confirm(`Extend subscription by ${days} days?`)) {
        return;
    }
    
    try {
        const result = await apiRequest(`/admin/users/${userId}/extend`, 'POST', { days });
        
        if (result && result.success) {
            alert(result.message);
            closeModal('userDetailsModal');
            loadUsers();
        }
    } catch (error) {
        console.error('Error extending subscription:', error);
        alert('Failed to extend subscription');
    }
}

async function banUser(userId, isBanned) {
    const reason = isBanned ? prompt('Reason for ban:') : null;
    
    if (isBanned && !reason) return;
    
    try {
        const result = await apiRequest(`/admin/users/${userId}/ban`, 'POST', { is_banned: isBanned, reason });
        
        if (result && result.success) {
            alert(result.message);
            closeModal('userDetailsModal');
            loadUsers();
        }
    } catch (error) {
        console.error('Error banning user:', error);
        alert('Failed to ban user');
    }
}

// MARK: - Create User

function showCreateUserModal() {
    showModal('createUserModal');
}

async function handleCreateUser(e) {
    e.preventDefault();
    
    const email = document.getElementById('newUserEmail').value;
    const password = document.getElementById('newUserPassword').value;
    const subscription_status = document.getElementById('newUserStatus').value;
    const subscription_days = parseInt(document.getElementById('newUserDays').value);
    
    try {
        // Username is automatically set to email on the backend
        const result = await apiRequest('/admin/users', 'POST', {
            email,
            password,
            subscription_status,
            subscription_days
        });
        
        if (result && result.success) {
            alert(result.message);
            closeModal('createUserModal');
            document.getElementById('createUserForm').reset();
            loadUsers();
        } else {
            alert(result.error || 'Failed to create user');
        }
    } catch (error) {
        console.error('Error creating user:', error);
        alert('Failed to create user');
    }
}

// MARK: - Delete User

async function deleteUser(userId, userEmail) {
    if (!confirm(`Are you sure you want to DELETE user ${userEmail}?\n\nThis action cannot be undone and will remove all user data including subscription history.`)) {
        return;
    }
    
    // Double confirmation for safety
    const confirmation = prompt('Type DELETE to confirm:');
    if (confirmation !== 'DELETE') {
        alert('Deletion cancelled');
        return;
    }
    
    try {
        const result = await apiRequest(`/admin/users/${userId}`, 'DELETE');
        
        if (result && result.success) {
            alert(result.message);
            closeModal('userDetailsModal');
            loadUsers();
        } else {
            alert(result.error || 'Failed to delete user');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        alert('Failed to delete user');
    }
}

// MARK: - Change Password

function showChangePasswordModal(userId) {
    document.getElementById('changePasswordUserId').value = userId;
    document.getElementById('changePasswordForm').reset();
    closeModal('userDetailsModal');
    showModal('changePasswordModal');
}

async function handleChangePassword(e) {
    e.preventDefault();
    
    const userId = document.getElementById('changePasswordUserId').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (newPassword !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }
    
    if (newPassword.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }
    
    try {
        const result = await apiRequest(`/admin/users/${userId}/password`, 'PUT', {
            new_password: newPassword
        });
        
        if (result && result.success) {
            alert(result.message);
            closeModal('changePasswordModal');
            loadUsers();
        } else {
            alert(result.error || 'Failed to update password');
        }
    } catch (error) {
        console.error('Error updating password:', error);
        alert('Failed to update password');
    }
}

// MARK: - Edit Membership

function showEditMembershipModal(userId, userDataStr) {
    const userData = JSON.parse(userDataStr.replace(/&quot;/g, '"'));
    
    document.getElementById('editMembershipUserId').value = userId;
    document.getElementById('editMembershipStatus').value = '';
    
    // Set current dates
    if (userData.subscription_start_date) {
        const startDate = new Date(userData.subscription_start_date);
        document.getElementById('editMembershipStartDate').value = formatDateTimeLocal(startDate);
    }
    
    if (userData.subscription_end_date) {
        const endDate = new Date(userData.subscription_end_date);
        document.getElementById('editMembershipEndDate').value = formatDateTimeLocal(endDate);
    }
    
    closeModal('userDetailsModal');
    showModal('editMembershipModal');
}

async function handleEditMembership(e) {
    e.preventDefault();
    
    const userId = document.getElementById('editMembershipUserId').value;
    const subscription_status = document.getElementById('editMembershipStatus').value;
    const subscription_start_date = document.getElementById('editMembershipStartDate').value;
    const subscription_end_date = document.getElementById('editMembershipEndDate').value;
    
    const updates = {};
    
    if (subscription_status) {
        updates.subscription_status = subscription_status;
    }
    
    if (subscription_start_date) {
        updates.subscription_start_date = new Date(subscription_start_date).toISOString();
    }
    
    if (subscription_end_date) {
        updates.subscription_end_date = new Date(subscription_end_date).toISOString();
    }
    
    if (Object.keys(updates).length === 0) {
        alert('No changes to save');
        return;
    }
    
    try {
        const result = await apiRequest(`/admin/users/${userId}/membership`, 'PUT', updates);
        
        if (result && result.success) {
            alert(result.message);
            closeModal('editMembershipModal');
            loadUsers();
        } else {
            alert(result.error || 'Failed to update membership');
        }
    } catch (error) {
        console.error('Error updating membership:', error);
        alert('Failed to update membership');
    }
}

// MARK: - Promo Codes

async function loadPromoCodes() {
    try {
        const data = await apiRequest('/admin/promo-codes', 'GET');
        
        if (data && data.promo_codes) {
            displayPromoCodes(data.promo_codes);
        }
    } catch (error) {
        console.error('Error loading promo codes:', error);
    }
}

function displayPromoCodes(codes) {
    if (!codes || codes.length === 0) {
        document.getElementById('promoCodesTable').innerHTML = '<p class="loading">No promo codes found</p>';
        return;
    }
    
    const html = `
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Duration</th>
                    <th>Uses</th>
                    <th>Active</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${codes.map(code => `
                    <tr>
                        <td><strong>${code.code}</strong></td>
                        <td>${code.duration_days} days</td>
                        <td>${code.used_count} / ${code.uses_total === -1 ? '∞' : code.uses_total}</td>
                        <td>${code.active ? '✅' : '❌'}</td>
                        <td>${formatDate(code.created_at)}</td>
                        <td>
                            <button class="btn btn-${code.active ? 'danger' : 'success'} btn-sm" 
                                    onclick="togglePromoCode(${code.id}, ${!code.active})">
                                ${code.active ? 'Deactivate' : 'Activate'}
                            </button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    document.getElementById('promoCodesTable').innerHTML = html;
}

async function handleCreatePromo(e) {
    e.preventDefault();
    
    const code = document.getElementById('promoCode').value;
    const duration = parseInt(document.getElementById('promoDuration').value);
    const uses = document.getElementById('promoUses').value;
    const description = document.getElementById('promoDescription').value;
    const expires = document.getElementById('promoExpires').value;
    
    try {
        const result = await apiRequest('/admin/promo-codes', 'POST', {
            code,
            duration_days: duration,
            uses_total: uses ? parseInt(uses) : -1,
            description,
            expires_at: expires || null
        });
        
        if (result && result.success) {
            alert(result.message);
            closeModal('createPromoModal');
            document.getElementById('createPromoForm').reset();
            loadPromoCodes();
        }
    } catch (error) {
        console.error('Error creating promo code:', error);
        alert('Failed to create promo code');
    }
}

async function togglePromoCode(codeId, active) {
    try {
        const result = await apiRequest(`/admin/promo-codes/${codeId}`, 'PUT', { active });
        
        if (result && result.success) {
            loadPromoCodes();
        }
    } catch (error) {
        console.error('Error toggling promo code:', error);
        alert('Failed to toggle promo code');
    }
}

// MARK: - Utilities

function showModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function showCreatePromoModal() {
    showModal('createPromoModal');
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

function formatDateTimeLocal(date) {
    // Format date for datetime-local input
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
}

function showError(elementId, message) {
    const el = document.getElementById(elementId);
    el.textContent = message;
    el.style.display = 'block';
    setTimeout(() => {
        el.style.display = 'none';
    }, 5000);
}


