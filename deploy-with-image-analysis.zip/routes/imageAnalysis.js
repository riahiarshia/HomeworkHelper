/**
 * Image Analysis Routes
 * Handles image validation and homework analysis
 */

const express = require('express');
const multer = require('multer');
const router = express.Router();

// Configure multer for image uploads
const storage = multer.memoryStorage();
const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024 // 10MB limit
    }
});

/**
 * POST /api/validate-image
 * Validates image quality for homework analysis
 */
router.post('/validate-image', upload.single('image'), async (req, res) => {
    try {
        console.log('🔍 Image validation request received');
        
        if (!req.file) {
            return res.status(400).json({ 
                error: 'No image file provided',
                isValid: false,
                issues: ['No image file uploaded']
            });
        }
        
        const imageBuffer = req.file.buffer;
        const imageSize = imageBuffer.length;
        
        console.log(`📊 Image size: ${(imageSize / 1024).toFixed(2)} KB`);
        
        // Basic validation rules
        const issues = [];
        
        // Check file size (minimum 10KB, maximum 10MB)
        if (imageSize < 10 * 1024) {
            issues.push('Image is too small (minimum 10KB required)');
        }
        
        if (imageSize > 10 * 1024 * 1024) {
            issues.push('Image is too large (maximum 10MB allowed)');
        }
        
        // Check if it's a valid image format
        const isValidFormat = checkImageFormat(imageBuffer);
        if (!isValidFormat) {
            issues.push('Invalid image format (only JPEG, PNG, HEIC supported)');
        }
        
        const isValid = issues.length === 0;
        
        console.log(`✅ Image validation completed - Valid: ${isValid}, Issues: ${issues.length}`);
        
        res.json({
            isValid: isValid,
            issues: issues,
            imageSize: imageSize,
            recommendations: isValid ? [] : [
                'Ensure the image is clear and well-lit',
                'Make sure the homework text is readable',
                'Avoid blurry or dark images',
                'Crop to focus on the specific problem'
            ]
        });
        
    } catch (error) {
        console.error('Image validation error:', error);
        res.status(500).json({ 
            error: 'Image validation failed',
            isValid: false,
            issues: ['Server error during validation']
        });
    }
});

/**
 * POST /api/analyze-homework
 * Analyzes homework image and provides solutions
 */
router.post('/analyze-homework', upload.single('image'), async (req, res) => {
    try {
        console.log('🔍 Homework analysis request received');
        
        const { problemText, userGradeLevel } = req.body;
        const imageFile = req.file;
        
        if (!imageFile && !problemText) {
            return res.status(400).json({ 
                error: 'Either image file or problem text is required' 
            });
        }
        
        console.log(`📊 Analysis request - Image: ${!!imageFile}, Text: ${!!problemText}, Grade: ${userGradeLevel}`);
        
        // For now, return a mock analysis since OpenAI integration would require API keys
        const mockAnalysis = {
            problem: problemText || "Math problem from image",
            solution: "Here's how to solve this step by step...",
            steps: [
                "Step 1: Identify the type of problem",
                "Step 2: Apply the appropriate formula",
                "Step 3: Solve for the unknown variable",
                "Step 4: Check your answer"
            ],
            explanation: "This is a sample explanation. In a real implementation, this would be generated using AI analysis of the homework image.",
            gradeLevel: userGradeLevel || "Unknown",
            subject: "Mathematics",
            difficulty: "Medium",
            estimatedTime: "5-10 minutes",
            hasImage: !!imageFile,
            imageSize: imageFile ? imageFile.size : 0
        };
        
        console.log('✅ Mock homework analysis completed');
        
        res.json({
            success: true,
            analysis: mockAnalysis,
            timestamp: new Date().toISOString()
        });
        
    } catch (error) {
        console.error('Homework analysis error:', error);
        res.status(500).json({ 
            error: 'Homework analysis failed',
            message: error.message 
        });
    }
});

/**
 * Helper function to check image format
 */
function checkImageFormat(buffer) {
    // Check for common image file signatures
    const signatures = [
        { offset: 0, bytes: [0xFF, 0xD8, 0xFF] }, // JPEG
        { offset: 0, bytes: [0x89, 0x50, 0x4E, 0x47] }, // PNG
        { offset: 0, bytes: [0x47, 0x49, 0x46] }, // GIF
        { offset: 4, bytes: [0x66, 0x74, 0x79, 0x70] } // HEIC/HEIF (simplified check)
    ];
    
    for (const sig of signatures) {
        if (buffer.length > sig.offset + sig.bytes.length) {
            const matches = sig.bytes.every((byte, index) => 
                buffer[sig.offset + index] === byte
            );
            if (matches) return true;
        }
    }
    
    return false;
}

module.exports = router;
