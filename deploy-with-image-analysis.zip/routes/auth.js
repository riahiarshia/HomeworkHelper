const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { Pool } = require('pg');
const { generateToken } = require('../middleware/auth');
const { generateAdminToken } = require('../middleware/adminAuth');
const { sendPasswordResetEmail, sendWelcomeEmail } = require('../services/emailService');

// Simple password hashing (replace with bcrypt later for production)
function hashPassword(password) {
    return crypto.createHash('sha256').update(password).digest('hex');
}

function verifyPassword(password, hash) {
    return hashPassword(password) === hash;
}

// Database connection
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

/**
 * POST /api/auth/admin-login
 * Admin login endpoint
 */
router.post('/admin-login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ error: 'Username and password required' });
        }
        
        // Get admin user
        const result = await pool.query(
            'SELECT * FROM admin_users WHERE username = $1 AND is_active = true',
            [username]
        );
        
        if (result.rows.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        const admin = result.rows[0];
        
        // Verify password
        const validPassword = verifyPassword(password, admin.password_hash);
        
        if (!validPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        // Update last login
        await pool.query(
            'UPDATE admin_users SET last_login = NOW() WHERE id = $1',
            [admin.id]
        );
        
        // Generate token
        const token = generateAdminToken(admin.id, admin.username, admin.email);
        
        res.json({
            success: true,
            token,
            admin: {
                id: admin.id,
                username: admin.username,
                email: admin.email,
                role: admin.role
            }
        });
        
    } catch (error) {
        console.error('Admin login error:', error);
        res.status(500).json({ error: 'Login failed' });
    }
});

/**
 * POST /api/auth/login
 * Login with email and password
 */
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password required' });
        }
        
        // Get user by email
        const result = await pool.query(
            'SELECT * FROM users WHERE email = $1',
            [email.toLowerCase()]
        );
        
        if (result.rows.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        const user = result.rows[0];
        
        // Check if user has password (not OAuth user)
        if (!user.password_hash) {
            return res.status(401).json({ error: 'Please use social login for this account' });
        }
        
        // Verify password with bcrypt
        const bcrypt = require('bcrypt');
        const validPassword = await bcrypt.compare(password, user.password_hash);
        
        if (!validPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        // Check if account is banned or inactive
        if (user.is_banned) {
            return res.status(403).json({ error: 'Account has been banned. Reason: ' + (user.banned_reason || 'Violation of terms') });
        }
        
        if (!user.is_active) {
            return res.status(403).json({ error: 'Account is inactive. Please contact support.' });
        }
        
        // Update last active
        await pool.query(
            'UPDATE users SET last_active_at = NOW() WHERE user_id = $1',
            [user.user_id]
        );
        
        // Generate JWT token
        const token = generateToken(user.user_id, email);
        
        // Calculate days remaining
        const now = new Date();
        const endDate = user.subscription_end_date ? new Date(user.subscription_end_date) : null;
        let daysRemaining = 0;
        
        if (endDate) {
            const diffTime = endDate - now;
            daysRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
        }
        
        res.json({
            userId: user.user_id,
            email: user.email,
            token: token,
            age: null, // Not stored in current schema
            grade: null, // Not stored in current schema
            subscription_status: user.subscription_status,
            subscription_end_date: user.subscription_end_date,
            days_remaining: daysRemaining
        });
        
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Login failed' });
    }
});

/**
 * POST /api/auth/register
 * Register new user with email and password
 */
router.post('/register', async (req, res) => {
    try {
        const { email, password, age, grade } = req.body;
        
        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password required' });
        }
        
        // Check if user already exists
        const existingUser = await pool.query(
            'SELECT * FROM users WHERE email = $1',
            [email.toLowerCase()]
        );
        
        if (existingUser.rows.length > 0) {
            return res.status(400).json({ error: 'User with this email already exists' });
        }
        
        // Hash password with bcrypt
        const bcrypt = require('bcrypt');
        const password_hash = await bcrypt.hash(password, 10);
        
        // Generate user ID
        const { v4: uuidv4 } = require('uuid');
        const user_id = uuidv4();
        
        // Calculate trial dates
        const subscription_start_date = new Date();
        const subscription_end_date = new Date();
        subscription_end_date.setDate(subscription_end_date.getDate() + 14); // 14-day trial
        
        // Create user
        const result = await pool.query(`
            INSERT INTO users (
                user_id, email, username, password_hash, auth_provider,
                subscription_status, subscription_start_date, subscription_end_date,
                is_active, is_banned
            )
            VALUES ($1, $2, $3, $4, 'email', 'trial', $5, $6, true, false)
            RETURNING *
        `, [
            user_id,
            email.toLowerCase(),
            email.toLowerCase(), // username = email
            password_hash,
            subscription_start_date,
            subscription_end_date
        ]);
        
        const user = result.rows[0];
        
        // Log trial start
        await pool.query(`
            INSERT INTO subscription_history (user_id, event_type, new_status, new_end_date)
            VALUES ($1, 'trial_started', 'trial', $2)
        `, [user_id, subscription_end_date]);
        
        // Generate JWT token
        const token = generateToken(user_id, email);
        
        // Send welcome email (don't wait for it)
        sendWelcomeEmail(email, email.split('@')[0]).catch(err => {
            console.error('Failed to send welcome email:', err);
        });
        
        res.status(201).json({
            userId: user.user_id,
            email: user.email,
            token: token,
            age: age || null,
            grade: grade || null,
            subscription_status: 'trial',
            days_remaining: 14,
            createdAt: user.created_at
        });
        
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Registration failed' });
    }
});

/**
 * POST /api/auth/google
 * Google Sign-In authentication endpoint
 */
router.post('/google', async (req, res) => {
    try {
        const { googleIdToken, email, name } = req.body;
        
        if (!email || !name) {
            return res.status(400).json({ error: 'Email and name required for Google authentication' });
        }
        
        console.log(`🔍 Google authentication attempt for: ${email} (${name})`);
        
        // Check if user exists by email
        const existingUser = await pool.query(
            'SELECT * FROM users WHERE email = $1',
            [email.toLowerCase()]
        );
        
        if (existingUser.rows.length > 0) {
            // User exists, update last active and login
            const user = existingUser.rows[0];
            
            await pool.query(
                'UPDATE users SET last_active_at = NOW() WHERE user_id = $1',
                [user.user_id]
            );
            
            const token = generateToken(user.user_id, email);
            
            // Calculate days remaining
            const now = new Date();
            const endDate = user.subscription_end_date ? new Date(user.subscription_end_date) : null;
            let daysRemaining = 0;
            
            if (endDate) {
                const diffTime = endDate - now;
                daysRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
            }
            
            console.log(`✅ Google authentication successful for existing user: ${email}`);
            
            return res.json({
                userId: user.user_id,
                email: user.email,
                token: token,
                age: null, // Not stored in current schema
                grade: null, // Not stored in current schema
                subscription_status: user.subscription_status,
                subscription_end_date: user.subscription_end_date,
                days_remaining: daysRemaining
            });
        }
        
        // Create new user with Google authentication
        const { v4: uuidv4 } = require('uuid');
        const user_id = uuidv4();
        
        // Calculate trial dates
        const subscription_start_date = new Date();
        const subscription_end_date = new Date();
        subscription_end_date.setDate(subscription_end_date.getDate() + 14); // 14-day trial
        
        // Create user with Google provider
        const result = await pool.query(`
            INSERT INTO users (
                user_id, email, username, auth_provider,
                subscription_status, subscription_start_date, subscription_end_date,
                is_active, is_banned
            )
            VALUES ($1, $2, $3, 'google', 'trial', $4, $5, true, false)
            RETURNING *
        `, [
            user_id,
            email.toLowerCase(),
            name, // Use Google name as username
            subscription_start_date,
            subscription_end_date
        ]);
        
        const user = result.rows[0];
        
        // Log trial start
        await pool.query(`
            INSERT INTO subscription_history (user_id, event_type, new_status, new_end_date)
            VALUES ($1, 'trial_started', 'trial', $2)
        `, [user_id, subscription_end_date]);
        
        // Generate JWT token
        const token = generateToken(user_id, email);
        
        console.log(`✅ Google authentication successful - new user created: ${email}`);
        
        res.status(201).json({
            userId: user.user_id,
            email: user.email,
            token: token,
            age: null,
            grade: null,
            subscription_status: 'trial',
            subscription_end_date: user.subscription_end_date,
            days_remaining: 14,
            createdAt: user.created_at
        });
        
    } catch (error) {
        console.error('Google authentication error:', error);
        res.status(500).json({ error: 'Google authentication failed' });
    }
});

/**
 * POST /api/auth/oauth-register
 * Register or update user after OAuth authentication (Google, Apple, etc.)
 */
router.post('/oauth-register', async (req, res) => {
    try {
        const { user_id, email, username, provider } = req.body;
        
        if (!user_id || !email) {
            return res.status(400).json({ error: 'User ID and email required' });
        }
        
        // Check if user exists
        const existingUser = await pool.query(
            'SELECT * FROM users WHERE user_id = $1',
            [user_id]
        );
        
        if (existingUser.rows.length > 0) {
            // User exists, update last active
            await pool.query(
                'UPDATE users SET last_active_at = NOW() WHERE user_id = $1',
                [user_id]
            );
            
            const user = existingUser.rows[0];
            const token = generateToken(user_id, email);
            
            // Calculate days remaining
            const now = new Date();
            const endDate = user.subscription_end_date ? new Date(user.subscription_end_date) : null;
            let daysRemaining = 0;
            
            if (endDate) {
                const diffTime = endDate - now;
                daysRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
            }
            
            return res.json({
                success: true,
                token,
                user: {
                    user_id: user.user_id,
                    email: user.email,
                    subscription_status: user.subscription_status,
                    days_remaining: daysRemaining
                }
            });
        }
        
        // Create new user with 14-day trial
        const trialEndDate = new Date();
        trialEndDate.setDate(trialEndDate.getDate() + 14);
        
        const result = await pool.query(`
            INSERT INTO users (
                user_id, email, username, auth_provider,
                subscription_status, subscription_start_date, subscription_end_date
            ) VALUES ($1, $2, $3, $4, 'trial', NOW(), $5)
            RETURNING *
        `, [user_id, email, email, provider, trialEndDate]); // username = email
        
        const user = result.rows[0];
        
        // Log trial start
        await pool.query(`
            INSERT INTO subscription_history (user_id, event_type, new_status, new_end_date)
            VALUES ($1, 'trial_started', 'trial', $2)
        `, [user_id, trialEndDate]);
        
        const token = generateToken(user_id, email);
        
        res.json({
            success: true,
            token,
            user: {
                user_id: user.user_id,
                email: user.email,
                subscription_status: 'trial',
                days_remaining: 14,
                trial_started: true
            }
        });
        
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Registration failed' });
    }
});

/**
 * POST /api/auth/request-reset
 * Request password reset - sends email with reset link
 */
router.post('/request-reset', async (req, res) => {
    try {
        const { email } = req.body;
        
        if (!email || !email.includes('@')) {
            return res.status(400).json({ error: 'Valid email address required' });
        }
        
        // Find user by email (case-insensitive)
        const userResult = await pool.query(
            'SELECT user_id, email, username FROM users WHERE email = $1',
            [email.toLowerCase()]
        );
        
        // Always return success to prevent email enumeration attacks
        // (don't reveal if email exists or not)
        if (userResult.rows.length === 0) {
            return res.json({
                success: true,
                message: 'If that email exists in our system, a reset link has been sent'
            });
        }
        
        const user = userResult.rows[0];
        
        // Check if user has a password (not OAuth-only account)
        const checkPassword = await pool.query(
            'SELECT password_hash FROM users WHERE user_id = $1',
            [user.user_id]
        );
        
        if (!checkPassword.rows[0].password_hash) {
            return res.json({
                success: true,
                message: 'If that email exists in our system, a reset link has been sent'
            });
        }
        
        // Generate secure reset token (32 bytes = 64 hex characters)
        const resetToken = crypto.randomBytes(32).toString('hex');
        
        // Set expiration to 1 hour from now
        const expiresAt = new Date(Date.now() + 60 * 60 * 1000);
        
        // Save token to database
        await pool.query(
            `INSERT INTO password_reset_tokens (user_id, token, expires_at)
             VALUES ($1, $2, $3)`,
            [user.user_id, resetToken, expiresAt]
        );
        
        // Send email with reset link
        try {
            await sendPasswordResetEmail(
                user.email,
                resetToken,
                user.username || user.email.split('@')[0]
            );
            
            console.log(`✅ Password reset requested for ${user.email}`);
            
            res.json({
                success: true,
                message: 'If that email exists in our system, a reset link has been sent'
            });
        } catch (emailError) {
            console.error('⚠️  Failed to send reset email (SendGrid not configured):', emailError.message);
            
            // Token is still saved in DB for testing
            // In testing mode, return success anyway so developers can test with deep links
            console.log(`⚠️  Token saved in database for manual testing`);
            console.log(`📱 Deep link: homeworkhelper://reset-password?token=${resetToken}`);
            
            res.json({
                success: true,
                message: 'Password reset requested. (Email not configured - check server logs for reset link)'
            });
        }
        
    } catch (error) {
        console.error('Password reset request error:', error);
        res.status(500).json({
            error: 'Failed to process password reset request'
        });
    }
});

/**
 * POST /api/auth/reset-password
 * Reset password using token from email
 */
router.post('/reset-password', async (req, res) => {
    try {
        const { token, newPassword } = req.body;
        
        // Validate input
        if (!token) {
            return res.status(400).json({ error: 'Reset token is required' });
        }
        
        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({
                error: 'Password must be at least 6 characters long'
            });
        }
        
        // Find valid, unused, non-expired token
        const tokenResult = await pool.query(
            `SELECT rt.id, rt.user_id, rt.expires_at, rt.used
             FROM password_reset_tokens rt
             WHERE rt.token = $1 
               AND rt.used = FALSE 
               AND rt.expires_at > NOW()`,
            [token]
        );
        
        if (tokenResult.rows.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'Invalid or expired reset token'
            });
        }
        
        const resetToken = tokenResult.rows[0];
        
        // Hash the new password with bcrypt
        const bcrypt = require('bcrypt');
        const passwordHash = await bcrypt.hash(newPassword, 10);
        
        // Update user's password
        await pool.query(
            'UPDATE users SET password_hash = $1, updated_at = NOW() WHERE user_id = $2',
            [passwordHash, resetToken.user_id]
        );
        
        // Mark token as used
        await pool.query(
            'UPDATE password_reset_tokens SET used = TRUE, used_at = NOW() WHERE id = $1',
            [resetToken.id]
        );
        
        console.log(`✅ Password reset successful for user ${resetToken.user_id}`);
        
        res.json({
            success: true,
            message: 'Password successfully reset'
        });
        
    } catch (error) {
        console.error('Password reset error:', error);
        res.status(500).json({
            error: 'Failed to reset password'
        });
    }
});

/**
 * GET /api/auth/verify-reset-token
 * Verify if a reset token is valid (optional endpoint for client validation)
 */
router.get('/verify-reset-token', async (req, res) => {
    try {
        const { token } = req.query;
        
        if (!token) {
            return res.status(400).json({ error: 'Token is required' });
        }
        
        // Check if token is valid, unused, and not expired
        const tokenResult = await pool.query(
            `SELECT id FROM password_reset_tokens
             WHERE token = $1 
               AND used = FALSE 
               AND expires_at > NOW()`,
            [token]
        );
        
        res.json({
            valid: tokenResult.rows.length > 0
        });
        
    } catch (error) {
        console.error('Token verification error:', error);
        res.status(500).json({ error: 'Failed to verify token' });
    }
});

module.exports = router;

