const axios = require('axios');
const config = require('../config');

class OpenAIService {
  constructor() {
    this.baseURL = config.openai.baseURL;
  }

  async validateImageQuality({ imageData, apiKey }) {
    const systemPrompt = `You are an image quality assessor for homework analysis. Evaluate the image quality for homework analysis purposes.

    CRITICAL QUALITY CHECKS:
    1. **Text Readability**: Can all text, numbers, and symbols be clearly read?
    2. **Image Sharpness**: Is the image in focus and not blurry?
    3. **Lighting**: Is the image well-lit without shadows or glare?
    4. **Completeness**: Is the entire homework visible without being cut off?
    5. **Resolution**: Is the image high enough resolution to read small text?
    6. **Orientation**: Is the image properly oriented (not upside down or sideways)?

    RESPOND WITH EXACTLY THIS JSON FORMAT:
    {
      "isGoodQuality": true/false,
      "confidence": 0.0-1.0,
      "issues": ["specific issue 1", "specific issue 2"],
      "recommendations": ["specific recommendation 1", "specific recommendation 2"]
    }

    QUALITY STANDARDS:
    - **Good Quality**: Text is clear, image is sharp, well-lit, complete, and properly oriented
    - **Poor Quality**: Blurry text, poor lighting, cut-off content, or any readability issues

    Be strict but fair in your assessment.`;

    const base64Image = imageData.toString('base64');
    const dataURL = `data:image/jpeg;base64,${base64Image}`;

    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: [
        { type: "text", text: "Please evaluate the quality of this homework image for analysis purposes. Check for text readability, image sharpness, lighting, completeness, and orientation." },
        { type: "image_url", image_url: { url: dataURL } }
      ]}
    ];

    const requestBody = {
      model: config.openai.model,
      messages: messages,
      max_tokens: 500,
      temperature: 0.1, // Low temperature for consistent quality assessment
      response_format: { type: "json_object" }
    };

    try {
      const response = await axios.post(`${this.baseURL}/chat/completions`, requestBody, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000 // 30 second timeout for validation
      });

      if (response.data && response.data.choices && response.data.choices[0]) {
        const content = response.data.choices[0].message.content;
        return JSON.parse(content);
      } else {
        throw new Error('Invalid response from OpenAI API');
      }
    } catch (error) {
      if (error.response) {
        if (error.response.status === 401) {
          const authError = new Error('Invalid OpenAI API key');
          authError.status = 401;
          throw authError;
        } else if (error.response.status === 429) {
          const rateLimitError = new Error('OpenAI API rate limit exceeded');
          rateLimitError.status = 429;
          throw rateLimitError;
        }
      }
      throw error;
    }
  }

  async analyzeHomework({ imageData, problemText, userGradeLevel, apiKey }) {
    const systemPrompt = `You are "Homework Mentor" — a precise and patient AI tutor that helps students solve their exact homework questions step by step.
    - Focus ONLY on the given problem or image, not general education.
    - Identify and restate ALL numbers and units exactly as written (say "unclear" if not visible).
    - Use 3–5 short steps with clear logic and a single correct answer.
    - Always output valid JSON with keys: subject, difficulty, steps (array of {question, explanation, options[], correctAnswer}), and finalAnswer.
    - Never include extra prose outside the JSON object.

    AGE-APPROPRIATE LANGUAGE for ${userGradeLevel}:
    
    Elementary (K-5):
    - Use simple words and concrete examples
    - Instead of formulas, show step-by-step addition/subtraction
    - Example: "length + length + width + width" NOT "2 × (length + width)"
    - Use visual language: "all four sides", "count each one", "add together"
    - Explanations should be like talking to a 10-year-old
    
    Middle School (6-8):
    - Can introduce basic formulas with explanations
    - Show both formula AND what it means in simple terms
    - Use more formal math language but keep it clear
    
    High School (9-12):
    - Use standard mathematical notation and formulas
    - Can use algebraic expressions and abstract concepts
    - Professional mathematical language is appropriate`;

    const userPrompt = `CRITICAL: Solve ALL problems on this homework sheet. Do not stop until every problem is addressed.

    STEP 1 - COUNT THE PROBLEMS:
    - Look at the entire homework sheet carefully
    - Count how many separate problems, questions, or exercises are visible
    - Note problem numbers if present (Problem 1, Problem 2, #1, #2, etc.)
    
    STEP 2 - SOLVE EACH PROBLEM COMPLETELY:
    - For EACH problem on the sheet, create 3–5 guided steps
    - Identify and restate ALL numbers, units, and data (e.g., 4 in, 6 ft, 12 units)
    - NEVER guess or assume numbers not shown. If unclear, say "unclear"
    - Each problem must have its own set of steps leading to its final answer
    
    STEP 3 - VERIFY COMPLETENESS:
    - Before finishing, count your step groups
    - Ensure you have steps for EVERY problem visible on the sheet
    - If you see 5 problems, you must create steps for all 5 problems
    - DO NOT finish until ALL problems are solved

    FORMAT RULES:
    Respond in JSON with this exact structure:
    {
      "subject": "Math / Science / English / etc.",
      "difficulty": "easy / medium / hard",
      "steps": [
        {
          "question": "Problem 1: [Identify the first problem and what it asks]",
          "explanation": "What we need to find for Problem 1",
          "options": ["Option A", "Option B", "Option C", "Option D"],
          "correctAnswer": "The exact correct option text"
        },
        {
          "question": "Problem 1: [Next step for solving Problem 1]",
          "explanation": "How to approach this step",
          "options": ["Option A", "Option B", "Option C", "Option D"],
          "correctAnswer": "The exact correct option text"
        },
        ... (3-5 steps for Problem 1)
        {
          "question": "Problem 2: [Identify the second problem]",
          "explanation": "What we need to find for Problem 2",
          "options": ["Option A", "Option B", "Option C", "Option D"],
          "correctAnswer": "The exact correct option text"
        },
        ... (3-5 steps for Problem 2)
        ... (continue for ALL problems on the sheet)
      ],
      "finalAnswer": "Summary: Problem 1 = [answer], Problem 2 = [answer], Problem 3 = [answer], etc."
    }

    GUIDING STYLE:
    - Use 3–5 short, targeted steps per problem
    - Label each step with which problem it's solving (e.g., "Problem 1:", "Problem 2:")
    - Each question should build toward that problem's answer
    - Include multiple choice options that make sense, but only one is fully correct
    - Do NOT reveal the correct answer inside the question or explanation text — only in "correctAnswer"
    - For word problems: identify key facts, convert them into equations, solve step by step

    SUBJECT BEHAVIOR:
    - Math: show equations, calculate step by step, include units
    - Science: identify data, explain reasoning, conclude clearly
    - English/Reading: identify context clues, grammar rules, or main idea
    - History/Social Studies: identify factual events, names, or causes/effects clearly

    MANDATORY: Create steps for EVERY problem visible on the homework sheet. Count them and verify completeness before responding.`;

    const messages = [
      { role: "system", content: systemPrompt }
    ];

    if (imageData) {
      const base64Image = imageData.toString('base64');
      const dataURL = `data:image/jpeg;base64,${base64Image}`;
      
      const contentArray = [
        { type: "text", text: userPrompt }
      ];
      
      if (problemText) {
        contentArray.push({ type: "text", text: `Additional context: ${problemText}` });
      }
      
      contentArray.push({
        type: "image_url",
        image_url: { url: dataURL }
      });
      
      messages.push({
        role: "user",
        content: contentArray
      });
    } else if (problemText) {
      messages.push({
        role: "user",
        content: `${userPrompt}\n\nProblem: ${problemText}`
      });
    }

    const requestBody = {
      model: config.openai.model,
      messages: messages,
      max_tokens: config.openai.maxTokens,
      temperature: config.openai.temperature,
      response_format: { type: "json_object" }
    };

    try {
      const response = await axios.post(`${this.baseURL}/chat/completions`, requestBody, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 60000 // 60 second timeout
      });

      if (response.data && response.data.choices && response.data.choices[0]) {
        const content = response.data.choices[0].message.content;
        return JSON.parse(content);
      } else {
        throw new Error('Invalid response from OpenAI API');
      }
    } catch (error) {
      if (error.response) {
        if (error.response.status === 401) {
          const authError = new Error('Invalid OpenAI API key');
          authError.status = 401;
          throw authError;
        } else if (error.response.status === 429) {
          const rateLimitError = new Error('OpenAI API rate limit exceeded');
          rateLimitError.status = 429;
          throw rateLimitError;
        }
      }
      throw error;
    }
  }

  async generateHint({ step, problemContext, userGradeLevel, apiKey }) {
    const systemPrompt = `You are "Homework Mentor" — a precise and patient AI tutor that helps students solve their exact homework questions step by step.
    Provide a subtle hint without giving away the answer. Use age-appropriate language and examples for ${userGradeLevel}.
    
    CRITICAL AGE-APPROPRIATE GUIDANCE:
    
    For Elementary Students (K-5):
    - Use concrete, visual examples instead of abstract formulas
    - Break complex concepts into simple repeated additions
    - Example: Instead of "2 × (length + width)", say "Add all four sides: length + length + width + width"
    - Use drawings in words: "Imagine the rectangle has 2 long sides and 2 short sides"
    - Show actual numbers without revealing the final answer: "If the sides are 5 and 3, add: 5 + 5 + 3 + 3"
    - Use everyday language: "count", "add together", "put side by side"
    
    For Middle School (6-8):
    - Can introduce simple formulas with explanations
    - Show both the formula AND the concrete breakdown
    - Example: "Perimeter = 2 × length + 2 × width, which means adding the two long sides and two short sides"
    - Use visual representations when helpful
    
    For High School (9-12):
    - Can use standard mathematical notation and formulas
    - Provide algebraic or formula-based hints
    - Example: "Use the formula P = 2(l + w) or 2l + 2w"
    
    IMPORTANT:
    - NEVER provide the final numerical answer
    - Show the pattern or method, not the solution
    - Guide thinking with questions: "What are we adding together?"
    - Use specific numbers from the problem to illustrate WITHOUT solving completely
    
    Focus on guiding the student's thinking, not solving for them.`;

    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: `Question: ${step.question}\nContext: ${problemContext}\nGrade Level: ${userGradeLevel}\n\nProvide a helpful, age-appropriate hint that shows the thinking process but doesn't give away the final answer.` }
    ];

    const requestBody = {
      model: config.openai.model,
      messages: messages,
      max_tokens: 400,
      temperature: config.openai.temperature
    };

    try {
      const response = await axios.post(`${this.baseURL}/chat/completions`, requestBody, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000 // 30 second timeout
      });

      if (response.data && response.data.choices && response.data.choices[0]) {
        return response.data.choices[0].message.content;
      } else {
        throw new Error('Invalid response from OpenAI API');
      }
    } catch (error) {
      if (error.response) {
        if (error.response.status === 401) {
          const authError = new Error('Invalid OpenAI API key');
          authError.status = 401;
          throw authError;
        } else if (error.response.status === 429) {
          const rateLimitError = new Error('OpenAI API rate limit exceeded');
          rateLimitError.status = 429;
          throw rateLimitError;
        }
      }
      throw error;
    }
  }

  async verifyAnswer({ answer, step, problemContext, userGradeLevel, apiKey }) {
    const systemPrompt = `You are "Homework Mentor" — a precise and patient AI tutor that helps students solve their exact homework questions step by step.
    You are verifying a student's homework answer. Accuracy is ESSENTIAL to prevent misleading the student.`;

    const userPrompt = `CRITICAL: You are verifying a student's homework answer. Accuracy is ESSENTIAL to prevent misleading the student.

    Question: ${step.question}
    Expected Correct Answer: ${step.correctAnswer}
    Student's Selected Answer: ${answer}
    All Available Options: ${step.options ? step.options.join(', ') : 'N/A'}
    
    VERIFICATION REQUIREMENTS:
    1. Check if the student's answer is mathematically/factually correct
    2. Consider equivalent expressions (e.g., "2+3" = "5", "half" = "0.5", "subtract 4" = "minus 4")
    3. Be strict about factual accuracy - if it's wrong, it's wrong
    4. Consider the student's grade level: ${userGradeLevel}
    
    EXAMPLES OF ACCEPTABLE VARIATIONS:
    - Mathematical: "5" = "five" = "2+3" = "10/2"
    - Operations: "add 3" = "plus 3" = "3 more"
    - Fractions: "1/2" = "half" = "0.5"
    
    RESPOND WITH EXACTLY ONE WORD:
    - "CORRECT" if the answer is right (including equivalent forms)
    - "INCORRECT" if the answer is wrong or misleading
    
    The student's education depends on your accuracy. Be thorough but fair.`;

    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ];

    const requestBody = {
      model: config.openai.model,
      messages: messages,
      max_tokens: 100,
      temperature: 0.0 // Deterministic for verification
    };

    try {
      const response = await axios.post(`${this.baseURL}/chat/completions`, requestBody, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000 // 30 second timeout
      });

      if (response.data && response.data.choices && response.data.choices[0]) {
        const content = response.data.choices[0].message.content;
        const trimmedResponse = content.trim().toUpperCase();
        const isCorrect = trimmedResponse.includes("CORRECT") && !trimmedResponse.includes("INCORRECT");
        
        return {
          isCorrect: isCorrect,
          verification: trimmedResponse
        };
      } else {
        throw new Error('Invalid response from OpenAI API');
      }
    } catch (error) {
      if (error.response) {
        if (error.response.status === 401) {
          const authError = new Error('Invalid OpenAI API key');
          authError.status = 401;
          throw authError;
        } else if (error.response.status === 429) {
          const rateLimitError = new Error('OpenAI API rate limit exceeded');
          rateLimitError.status = 429;
          throw rateLimitError;
        }
      }
      throw error;
    }
  }

  async generateChatResponse({ messages, problemContext, userGradeLevel, apiKey }) {
    const systemPrompt = `You are "Homework Mentor" — an intelligent and patient tutor that helps students solve their exact homework questions step by step.

CRITICAL BEHAVIORS:
- You must focus ONLY on the specific question or context provided
- Provide helpful, educational guidance without giving away answers
- Adapt your language and explanations to the student's grade level: ${userGradeLevel}
- Be encouraging and supportive while maintaining educational standards

AGE-APPROPRIATE GUIDANCE:
- Elementary (K-5): Use simple language, visual examples, concrete concepts
- Middle School (6-8): Introduce formulas with clear explanations
- High School (9-12): Use appropriate mathematical notation and abstract concepts`;

    // Convert iOS ChatMessage format to OpenAI format
    const openaiMessages = [
      { role: "system", content: systemPrompt },
      ...messages.map(msg => ({
        role: msg.role || "user", // Handle different message formats
        content: msg.content
      }))
    ];

    const requestBody = {
      model: config.openai.model,
      messages: openaiMessages,
      max_tokens: 800,
      temperature: 0.2
    };

    try {
      const response = await axios.post(`${this.baseURL}/chat/completions`, requestBody, {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000 // 30 second timeout
      });

      if (response.data && response.data.choices && response.data.choices[0]) {
        return response.data.choices[0].message.content;
      } else {
        throw new Error('Invalid response from OpenAI API');
      }
    } catch (error) {
      if (error.response) {
        if (error.response.status === 401) {
          const authError = new Error('Invalid OpenAI API key');
          authError.status = 401;
          throw authError;
        } else if (error.response.status === 429) {
          const rateLimitError = new Error('OpenAI API rate limit exceeded');
          rateLimitError.status = 429;
          throw rateLimitError;
        }
      }
      throw error;
    }
  }
}

module.exports = new OpenAIService();
